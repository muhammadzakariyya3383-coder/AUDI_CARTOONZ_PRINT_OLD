import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// This project is currently published from the AUDI_CARTOONZ_PRINT_OLD
// GitHub repository, so assets must use this repository base path.
export default defineConfig({
  base: "/AUDI_CARTOONZ_PRINT_OLD/",
  plugins: [react()]
});
