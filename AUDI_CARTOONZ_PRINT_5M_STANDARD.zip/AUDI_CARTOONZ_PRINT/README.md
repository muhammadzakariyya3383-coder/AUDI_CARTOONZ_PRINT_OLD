# AUDI CARTOONZ PRINT

A React + TypeScript + Vite foundation for the AUDI CARTOONZ PRINT business management system, branded for professional printing and garment branding services.

## Included
- Refreshed responsive visual design for mobile and desktop.
- Consistent AUDI CARTOONZ PRINT dashboard branding; staff personal names are not used as the dashboard brand.
- GitHub Pages asset base configured for the existing AUDI_CARTOONZ_PRINT_OLD repository.
- Customer confirmation email redirect points to the existing live GitHub Pages website.
- Shared sign-in screen for Owner, Admin 2 and customers.
- Customer self-registration using Supabase Auth (name, optional phone, email and password).
- Registration submits customer intent as user metadata; the database must independently assign the `customer` role.
- Existing role-aware navigation and profile lookup.
- Honest placeholders for business modules that are not yet implemented.

## Important: verify customer profile creation before public launch
This app does not change your Supabase database automatically. The existing Supabase project must have a secure Auth user trigger/profile creation process that creates a `profiles` row for each new auth user and assigns `customer` by default. Never trust a role supplied by a browser form or user metadata. Existing `admin1` and `admin2` accounts must retain their current roles. Verify the trigger, profile table columns, and Row Level Security policies in Supabase before inviting customers to register.

If email confirmation is enabled in Supabase, customers must confirm their email before signing in. The app displays a message telling them to check their inbox.

## Important deployment note
The GitHub Pages base path and email confirmation redirect in this starter are configured for:
`https://muhammadzakariyya3383-coder.github.io/AUDI_CARTOONZ_PRINT_OLD/`
If the repository name or hosting address changes, update both `vite.config.ts` and the `emailRedirectTo` value in `src/components/SignIn.tsx`, and add the matching URL in Supabase Authentication → URL Configuration.

## Current project status
The app foundation includes authentication, profile lookup, role-aware navigation, and responsive workspace screens. Order/customer/payment/expense CRUD, artwork storage, production workflow, receipts, audit logging, offline sync, and final security verification still require implementation and testing. Do not treat placeholder modules as completed features.

## Requirements
- Node.js 20.19+ or 22.12+
- npm
- Existing Supabase project

## Configure
1. Copy `.env.example` to `.env`.
2. Set `VITE_SUPABASE_URL` to the existing AUDI CARTOONZ PRINT Supabase project URL.
3. Set `VITE_SUPABASE_ANON_KEY` to its publishable key (or legacy anon key).
4. Never put a service-role or secret key in this frontend project.
5. Run `npm install` and `npm run dev`.

## Build
Run `npm run build`. A successful build creates the `dist` folder.
