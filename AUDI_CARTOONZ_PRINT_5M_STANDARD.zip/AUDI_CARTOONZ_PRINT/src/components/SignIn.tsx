import { useState } from "react";
import { ArrowRight, Eye, EyeOff, LockKeyhole, Mail, Printer, UserRound, Phone, Sparkles } from "lucide-react";
import { supabase } from "../lib/supabase";

type Mode = "signin" | "signup";

export default function SignIn() {
  const [mode, setMode] = useState<Mode>("signin");
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [success, setSuccess] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase) return;
    setBusy(true); setMessage(""); setSuccess(false);
    if (mode === "signup") {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          data: { full_name: fullName.trim(), phone: phone.trim() },
          // Return customers to the live GitHub Pages site after email confirmation.
          emailRedirectTo: "https://muhammadzakariyya3383-coder.github.io/AUDI_CARTOONZ_PRINT_OLD/"
        }
      });
      if (error) setMessage(error.message);
      else {
        setSuccess(true);
        setMessage(data.session
          ? "Your account has been created. You can now continue to your customer workspace."
          : "Your account has been created. Check your email for a confirmation link, then return here to sign in.");
        setMode("signin"); setPassword("");
      }
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) setMessage(error.message);
      else setMessage("Signed in. Loading your account…");
    }
    setBusy(false);
  }

  return <main className="login-wrap">
    <div className="login-layout">
      <section className="login-showcase">
        <div className="showcase-brand"><span className="showcase-logo"><Printer size={22}/></span><span>AUDI CARTOONZ <b>PRINT</b></span></div>
        <div className="showcase-copy">
          <span className="showcase-kicker"><Sparkles size={14}/> YOUR CREATIVE PRINT PARTNER</span>
          <h1>Ideas worth<br/><em>bringing to life.</em></h1>
          <p>Quality printing, thoughtful service and a smoother way to manage every print job.</p>
        </div>
        <div className="showcase-bottom"><span className="showcase-line"/> <span>PRINT WITH CONFIDENCE</span></div>
        <div className="showcase-orb orb-one"/><div className="showcase-orb orb-two"/>
      </section>
      <section className="login-side">
        <form className="login-card" onSubmit={submit}>
          <div className="mobile-brand"><span className="brand-mark"><Printer size={21}/></span><span>AUDI CARTOONZ PRINT</span></div>
          <p className="eyebrow">{mode === "signin" ? "WELCOME BACK" : "JOIN OUR PRINT COMMUNITY"}</p>
          <h2>{mode === "signin" ? "Sign in to your account" : "Create your customer account"}</h2>
          <p className="form-intro">{mode === "signin" ? "Enter your details to access your workspace." : "Register to place orders and follow your printing jobs."}</p>
          {!supabase && <div className="notice warning">Supabase is not configured. Add the existing project URL and publishable key to the deployment environment variables.</div>}
          {mode === "signup" && <>
            <label>Full name<div className="input-wrap"><UserRound size={17}/><input autoComplete="name" value={fullName} onChange={e=>setFullName(e.target.value)} placeholder="Your full name" required /></div></label>
            <label>Phone number <span className="optional">(optional)</span><div className="input-wrap"><Phone size={17}/><input autoComplete="tel" type="tel" value={phone} onChange={e=>setPhone(e.target.value)} placeholder="Your phone number" /></div></label>
          </>}
          <label>Email address<div className="input-wrap"><Mail size={17}/><input autoComplete="email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="name@example.com" required /></div></label>
          <label>Password<div className="input-wrap"><LockKeyhole size={17}/><input autoComplete={mode === "signin" ? "current-password" : "new-password"} type={showPassword ? "text" : "password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder={mode === "signup" ? "At least 8 characters" : "Enter your password"} minLength={mode === "signup" ? 8 : undefined} required /><button className="password-toggle" type="button" aria-label={showPassword ? "Hide password" : "Show password"} onClick={()=>setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div></label>
          {mode === "signup" && <p className="tiny muted role-note">Customer accounts are for customers only. Staff access is assigned separately by the business owner.</p>}
          <button className="primary-action" disabled={!supabase || busy}>{busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create customer account"}<ArrowRight size={17}/></button>
          {message && <p className={success ? "form-message success-message" : "form-message"} role="status">{message}</p>}
          <div className="switch-mode">{mode === "signin" ? <>New customer? <button type="button" onClick={()=>{setMode("signup");setMessage("");}}>Create an account</button></> : <>Already registered? <button type="button" onClick={()=>{setMode("signin");setMessage("");}}>Sign in instead</button></>}</div>
          <p className="tiny muted secure-note">Secure account access powered by Supabase.</p>
        </form>
      </section>
    </div>
  </main>;
}
