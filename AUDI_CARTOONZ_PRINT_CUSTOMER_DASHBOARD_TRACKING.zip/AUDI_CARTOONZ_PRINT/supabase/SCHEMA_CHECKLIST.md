# Supabase verification checklist (read-only first)

Before writing migrations or CRUD code, verify in the existing Supabase project:

- [ ] Project URL matches the original AUDI_CARTOONZ PRINT project.
- [ ] Tables: profiles, customers, orders, payments, expenses, production_updates, audit_logs, business_settings.
- [ ] Exact columns, types, nullability, defaults, primary keys, and foreign keys.
- [ ] `profiles.role` uses only `admin1`, `admin2`, `customer` as intended.
- [ ] Auth user creation trigger and function behavior are understood.
- [ ] RLS is enabled on every table.
- [ ] Inspect each policy's `USING` and `WITH CHECK` expressions, not just policy names/count.
- [ ] Customers can only read their own records and orders.
- [ ] Staff permissions are explicitly limited.
- [ ] Only admin1 can perform owner-only operations and manage roles.
- [ ] Storage bucket policies are reviewed before enabling artwork uploads.

Do not paste a service-role key into this application. Do not run destructive SQL to make the schema match this checklist.
