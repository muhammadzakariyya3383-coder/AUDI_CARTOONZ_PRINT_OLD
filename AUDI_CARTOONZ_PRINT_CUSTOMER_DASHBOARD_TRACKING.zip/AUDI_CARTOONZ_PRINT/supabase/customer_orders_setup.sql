-- AUDI CARTOONZ PRINT customer orders: additive setup.
-- Review your existing schema and policies before running. This does not delete existing users or profiles.
create table if not exists public.customer_orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('ACP-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  customer_id uuid not null references auth.users(id) on delete cascade,
  customer_name text not null,
  customer_phone text not null,
  service text not null,
  quantity integer not null check (quantity > 0),
  specifications text not null,
  status text not null default 'order_received',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Replace only this table's status constraint so the seven customer-facing stages are supported.
alter table public.customer_orders alter column status set default 'order_received';
alter table public.customer_orders drop constraint if exists customer_orders_status_check;
alter table public.customer_orders add constraint customer_orders_status_check
  check (status in ('order_received','design_in_progress','awaiting_approval','printing_in_progress','quality_check','completed','delivered_to_customer'));

alter table public.customer_orders enable row level security;

drop policy if exists "Customers view own orders" on public.customer_orders;
create policy "Customers view own orders" on public.customer_orders
for select to authenticated using (customer_id = auth.uid());

drop policy if exists "Customers create own orders" on public.customer_orders;
create policy "Customers create own orders" on public.customer_orders
for insert to authenticated with check (customer_id = auth.uid());

drop policy if exists "Staff view all customer orders" on public.customer_orders;
create policy "Staff view all customer orders" on public.customer_orders
for select to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin1','admin2')));

drop policy if exists "Staff update customer orders" on public.customer_orders;
create policy "Staff update customer orders" on public.customer_orders
for update to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin1','admin2')))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin1','admin2')));

grant select, insert on public.customer_orders to authenticated;
grant update (status) on public.customer_orders to authenticated;
