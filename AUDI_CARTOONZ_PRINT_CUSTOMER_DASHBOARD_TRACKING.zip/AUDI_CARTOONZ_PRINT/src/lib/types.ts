export type Role = "admin1" | "admin2" | "customer";
export type Profile = { id: string; full_name: string | null; role: Role; phone?: string | null };
export type NavKey = "overview" | "orders" | "customers" | "payments" | "expenses" | "production" | "activity" | "settings";
export const navigation: { key: NavKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "orders", label: "Orders" },
  { key: "customers", label: "Customers" },
  { key: "payments", label: "Payments" },
  { key: "expenses", label: "Expenses" },
  { key: "production", label: "Production" },
  { key: "activity", label: "Activity logs" },
  { key: "settings", label: "Settings" }
];
