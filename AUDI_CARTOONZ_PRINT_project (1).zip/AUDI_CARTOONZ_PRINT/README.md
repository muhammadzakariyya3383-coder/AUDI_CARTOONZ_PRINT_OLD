# AUDI_CARTOONZ PRINT

A React + TypeScript + Vite starter for the AUDI_CARTOONZ PRINT business management system.

## Important status

This is a **working application foundation, not a completed production system**. It includes a responsive shell, Supabase client configuration, email/password sign-in, profile lookup, role-aware navigation, and honest placeholder states for the business modules. It does not yet implement order/customer/payment/expense CRUD, production workflows, receipts, audit logging, offline sync, or final security verification.

Do not use it to run live business operations until the remaining modules and database policies have been implemented and tested.

## Requirements

- Node.js 20.19+ or 22.12+
- npm
- Existing Supabase project

## Run locally / in Codespaces

1. Copy `.env.example` to `.env`.
2. Set `VITE_SUPABASE_URL` to the existing Supabase project URL.
3. Set `VITE_SUPABASE_ANON_KEY` to its publishable key (or legacy anon key).
4. Never put a `service_role` or secret key in this frontend project.
5. Run `npm install`.
6. Run `npm run dev`.

In Codespaces, use the forwarded port shown by the Ports panel.

## Existing database

The original project was reported to contain `profiles`, `customers`, `orders`, `payments`, `expenses`, `production_updates`, `audit_logs`, and `business_settings`. Verify actual columns and RLS policies in the Supabase dashboard before implementing data operations. This starter deliberately does not run SQL or modify the database automatically.

## Roles

Expected role values: `admin1` (owner), `admin2` (manager), and `customer`. UI navigation is not a security boundary. Every database table must have correct Row Level Security policies enforced in Supabase.

## Safe next steps

1. Confirm the environment points to the correct existing Supabase project.
2. Inspect exact table columns, foreign keys, triggers, and RLS policy expressions.
3. Verify sign-in and profile retrieval.
4. Implement and test each business module against the verified schema.
5. Add audit trails, storage rules, realtime updates, offline queue/sync, exports, and deployment.
6. Conduct owner/manager/customer permission tests before production.

## Credentials

`.env` is ignored by Git. Do not commit credentials. A publishable key is intended for client use but still relies on correct RLS policies. Never expose secret keys.
