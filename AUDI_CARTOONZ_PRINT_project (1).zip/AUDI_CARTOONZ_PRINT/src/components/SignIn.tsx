import { useState } from "react";
import { supabase } from "../lib/supabase";

export default function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase) return;
    setBusy(true); setMessage("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setMessage(error ? error.message : "Signed in. Loading your account…");
    setBusy(false);
  }
  return <main className="login-wrap"><form className="login-card" onSubmit={submit}>
    <div className="brand-mark">AC</div><p className="eyebrow">PRINT BUSINESS MANAGEMENT</p>
    <h1>AUDI_CARTOONZ PRINT</h1><p className="muted">Sign in to manage your printing business.</p>
    {!supabase && <div className="notice warning">Supabase is not configured yet. Add your project URL and publishable key to the environment variables.</div>}
    <label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label>
    <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required /></label>
    <button disabled={!supabase || busy}>{busy ? "Signing in…" : "Sign in"}</button>
    {message && <p className="form-message">{message}</p>}
    <p className="tiny muted">Access is controlled by your Supabase account and database policies.</p>
  </form></main>;
}
