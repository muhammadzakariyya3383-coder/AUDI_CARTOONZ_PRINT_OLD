import { useEffect, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured } from "./lib/supabase";
import { navigation, type NavKey, type Profile } from "./lib/types";
import SignIn from "./components/SignIn";

function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [section, setSection] = useState<NavKey>("overview");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    let active = true;
    async function loadProfile() {
      if (!supabase || !session?.user) { setProfile(null); setLoading(false); return; }
      setLoading(true); setError("");
      const { data, error } = await supabase.from("profiles")
        .select("id, full_name, role, phone").eq("id", session.user.id).maybeSingle();
      if (!active) return;
      if (error) setError(`Could not load your profile: ${error.message}`);
      setProfile(data as Profile | null);
      setLoading(false);
    }
    loadProfile();
    return () => { active = false; };
  }, [session]);

  if (!isSupabaseConfigured || !session) return <SignIn />;
  if (loading) return <div className="center-screen">Loading your account…</div>;
  if (!profile) return <div className="center-screen"><div className="notice warning">{error || "Your profile was not found. Ask the system owner to check your profile record."}</div><button onClick={()=>supabase?.auth.signOut()}>Sign out</button></div>;

  const isStaff = profile.role === "admin1" || profile.role === "admin2";
  const visibleNav = isStaff ? navigation : navigation.filter(n => ["overview","orders"].includes(n.key));
  const title = navigation.find(n=>n.key===section)?.label ?? "Overview";

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark small">AC</div><div><strong>AUDI_CARTOONZ</strong><span>PRINT MANAGEMENT</span></div></div>
      <div className="side-label">WORKSPACE</div>
      <nav>{visibleNav.map(item=><button key={item.key} className={section===item.key?"nav-item active":"nav-item"} onClick={()=>setSection(item.key)}>{item.label}</button>)}</nav>
      <div className="sidebar-bottom"><span className="status-dot"/> Connected account<div className="muted tiny">{profile.role.toUpperCase()}</div><button className="signout" onClick={()=>supabase?.auth.signOut()}>Sign out</button></div>
    </aside>
    <main className="main"><header className="topbar"><div><p className="eyebrow">BUSINESS WORKSPACE</p><h1>{title}</h1></div><div className="user-chip"><span className="avatar">{(profile.full_name||"U").slice(0,1).toUpperCase()}</span><span>{profile.full_name || session.user.email}</span></div></header>
      {error && <div className="notice warning">{error}</div>}
      {section==="overview" ? <><section className="welcome"><div><p className="eyebrow">WELCOME BACK</p><h2>{profile.full_name || "Team member"}</h2><p>Manage print jobs, customers and business activity from one workspace.</p></div><div className="welcome-icon">✦</div></section>
      <div className="section-heading"><div><h2>Workspace overview</h2><p className="muted">Live records will appear here as modules are connected.</p></div></div>
      <div className="stats-grid">{[["Orders","orders"],["Customers","customers"],["Payments","payments"],["Expenses","expenses"]].map(([label,key])=><button className="stat-card" key={key} onClick={()=>setSection(key as NavKey)}><span>{label}</span><strong>—</strong><small>Open {label.toLowerCase()}</small></button>)}</div>
      <div className="notice">Your account is authenticated. This starter does not create sample records or pretend that unbuilt modules are complete.</div></>
      : <section className="module-panel"><p className="eyebrow">MODULE</p><h2>{title}</h2><p className="muted">This module is part of the project plan, but its database operations and permissions must be implemented and tested against your existing Supabase schema before it is used for real business records.</p><div className="notice">No demo data is being shown. The next development phase will implement this module using your verified database structure.</div></section>}
      <footer> AUDI_CARTOONZ PRINT · Secure business workspace</footer>
    </main>
  </div>;
}
export default App;
