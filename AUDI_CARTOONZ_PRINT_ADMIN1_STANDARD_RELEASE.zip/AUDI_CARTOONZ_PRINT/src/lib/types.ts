export type Role = "admin1" | "customer";
export type Profile = { id: string; full_name: string | null; role: Role; phone?: string | null };
export type NavKey = "overview" | "orders";
export const navigation: { key: NavKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "orders", label: "Orders" },
];
