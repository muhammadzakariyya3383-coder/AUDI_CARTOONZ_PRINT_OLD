# AUDI CARTOONZ PRINT — Admin1 Standard Release

This is the complete React + TypeScript + Vite source project for the existing AUDI CARTOONZ PRINT application.

## Admin access in this release
- The only staff role recognised by the frontend is `admin1`.
- `admin2` is not recognised as an administrator.
- Admin navigation contains **Overview** and **Orders** only.
- Overview opens the business workspace summary.
- Orders lets Admin1 review customer orders and update their order status.
- Customer accounts continue to use the separate customer dashboard and can view their own orders.
- There are no Payments, Expenses, Production, Activity Logs, or Settings menu entries in this release. Those modules are not implemented in this source and are intentionally not advertised as working features.
- The old generic “This module will be connected…” placeholder is not part of the Admin1 navigation or rendering path in this release.

## Important deployment instruction
The repository's current GitHub Actions workflow extracts a ZIP from the repository root. It chooses the first ZIP it finds. **Replace the existing root ZIP named `AUDI_CARTOONZ_PRINT_CUSTOMER_DASHBOARD_TRACKING.zip` with this release; do not upload this as an additional second ZIP.** Keeping multiple ZIPs at the repository root can cause GitHub Actions to extract the wrong/older application.

After replacing the ZIP, run the existing GitHub Actions workflow and confirm the build and Pages deployment both succeed. Then open:
`https://muhammadzakariyya3383-coder.github.io/AUDI_CARTOONZ_PRINT_OLD/`

## Supabase safety
- This release does not run SQL and does not modify the Supabase database.
- It does not delete, migrate, or overwrite customer records.
- Admin1 access depends on the signed-in user's existing `profiles.role` value being exactly `admin1`.
- The frontend queries `profiles(id, full_name, role, phone)` and uses the existing `customer_orders` table.
- Admin1 order access and status updates still depend on the existing Supabase Row Level Security policies permitting the `admin1` role.
- Do not expose a Supabase service-role key in this frontend. Configure only the project URL and publishable/anon key as GitHub Actions secrets.

## Requirements
- Node.js 20.19+ or 22.12+
- npm
- Existing Supabase project

## Configure locally
1. Copy `.env.example` to `.env`.
2. Set `VITE_SUPABASE_URL` to the existing Supabase project URL.
3. Set `VITE_SUPABASE_ANON_KEY` to the project's publishable/anon key.
4. Run `npm install`.
5. Run `npm run dev`.

## Build
Run `npm run build`. Vite writes the production site to `dist/`.

## Included source
- `src/App.tsx` — authentication, role routing, Admin1 workspace and navigation.
- `src/components/Orders.tsx` — customer order submission and Admin1 order management.
- `src/components/CustomerDashboard.tsx` — customer portal and order tracking.
- `src/components/SignIn.tsx` — Supabase sign-in and customer registration.
- `src/lib/` — Supabase client and application types.
- `supabase/customer_orders_setup.sql` — reference SQL for the order module; review before running it against any live database.

## Verification status
The source archive was inspected for this release. A fresh dependency install/build could not be completed in the preparation environment because `npm install` timed out. Therefore, do not treat this archive as a locally build-verified deployment. GitHub Actions must complete its build successfully before the live site is considered updated.
