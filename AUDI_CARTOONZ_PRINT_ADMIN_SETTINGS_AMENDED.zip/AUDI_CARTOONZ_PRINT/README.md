# AUDI CARTOONZ PRINT

A React + TypeScript + Vite foundation for the AUDI CARTOONZ PRINT business management system.

## Included
- Refreshed responsive visual design for mobile and desktop.
- Shared sign-in screen for Admin1 and customers.
- Customer self-registration using Supabase Auth (name, optional phone, email and password).
- Registration submits customer intent as user metadata; the database must independently assign the `customer` role.
- Existing role-aware navigation and profile lookup.
- Honest placeholders for business modules that are not yet implemented.

## Important: verify customer profile creation before public launch
This app does not change your Supabase database automatically. The existing Supabase project must have a secure Auth user trigger/profile creation process that creates a `profiles` row for each new auth user and assigns `customer` by default. Never trust a role supplied by a browser form or user metadata. Existing `admin1` accounts must retain their current roles. Verify the trigger, profile table columns, and Row Level Security policies in Supabase before inviting customers to register.

If email confirmation is enabled in Supabase, customers must confirm their email before signing in. The app displays a message telling them to check their inbox.

## Current project status
The app foundation includes authentication, profile lookup, role-aware navigation, and responsive workspace screens. Order/customer/payment/expense CRUD, artwork storage, production workflow, receipts, audit logging, offline sync, and final security verification still require implementation and testing. Do not treat placeholder modules as completed features.

## Requirements
- Node.js 20.19+ or 22.12+
- npm
- Existing Supabase project

## Configure
1. Copy `.env.example` to `.env`.
2. Set `VITE_SUPABASE_URL` to the existing AUDI CARTOONZ PRINT Supabase project URL.
3. Set `VITE_SUPABASE_ANON_KEY` to its publishable key (or legacy anon key).
4. Never put a service-role or secret key in this frontend project.
5. Run `npm install` and `npm run dev`.

## Build
Run `npm run build`. A successful build creates the `dist` folder.

## Customer ordering module
Customers can submit printing requests after signing in. Orders are stored in `public.customer_orders`; customers can read only their own orders, while staff roles `admin1` can view all requests and update status. Run `supabase/customer_orders_setup.sql` in the existing Supabase SQL Editor before publishing. This creates a separate table and does not delete or modify existing profiles, users, tables or records. Confirm your existing Auth trigger creates a `profiles` row with the `customer` role for new registrations. Email confirmation redirects to the deployed site base URL. Business contact: 08163671639 · Abubakaraudi888@gmail.com.


## Fixed customer ordering release (GitHub Pages)
This release opens the Orders page immediately after sign-in, keeps Orders visible for customer accounts, and uses the repository's GitHub Pages base path `/AUDI_CARTOONZ_PRINT_OLD/`.

### Before accepting real orders
1. Confirm the GitHub Actions deployment uses the existing `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` repository secrets.
2. In the existing Supabase project, review the current `profiles` table and auth-user trigger first.
3. Run `supabase/customer_orders_setup.sql` only after confirming the existing `profiles(id, role)` columns and role values `admin1`, `customer`.
4. Build and deploy, then test with a real customer account: sign in → Orders → submit a small test request → confirm it appears in Supabase and the Owner/Admin view.
5. Remove the test request after verification if desired.

This archive has not been tested against your live Supabase project because no project connection or schema access was provided. Do not overwrite the live site until the above test succeeds. Keep the previous repository version as a backup.


## Separate customer dashboard and order tracking
Customer accounts now use a dedicated customer portal, separate from the staff dashboard. The customer portal provides Overview, Place an order / My orders, contact details and a seven-stage order progress tracker:
1. Order Received
2. Design in Progress
3. Awaiting Approval
4. Printing in Progress
5. Quality Check
6. Completed
7. Delivered to Customer

The staff Orders page uses the same seven status values. If `customer_orders` already exists, run the updated SQL script to replace only that table's status check constraint. Review the existing schema and policies first. This package has not been connected to or tested against the live Supabase project.

## Admin1 dashboard restoration release

This release restores all eight Admin1 navigation sections and does not remove customer-facing pages or existing records. Admin access in the application is limited to the `admin1` role. The Customers screen reads customer rows from the existing `profiles` table; Orders and Production read the existing `customer_orders` table; Activity Logs displays recent order records and is explicitly not an audit log. Payments and Expenses are intentionally marked as awaiting verified table structure because the supplied project does not define those tables. Settings displays the signed-in Admin1 account without changing database settings. No production SQL has been run by this package. Review the existing Supabase schema and policies before applying any SQL.

## Expanded customer order form (Admin1 / customer portal)
The customer order form now captures item type (Jersey, T-shirt, Cap, Hoodie, Uniform, Other), quantity, sizes, colour, names/numbers, design instructions, optional design/logo file, delivery state/address/method, estimated amount and deposit paid. Submitted orders appear in the customer's **My orders** section and the staff Orders view.

### Supabase setup required
Before deploying this version, open the Supabase SQL Editor and run `supabase/customer_orders_setup.sql`. The script creates/updates the `customer_orders` structure additively and configures a private `order-designs` Storage bucket for optional files (5 MB limit). It does not delete existing orders. Review the SQL and your current policies before running it. The application cannot save the newly added fields or upload design files until this setup has been applied.
