-- AUDI CARTOONZ PRINT customer orders: additive setup.
-- Review your existing schema and policies before running. This does not delete existing users or profiles.
create table if not exists public.customer_orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('ACP-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  customer_id uuid not null references auth.users(id) on delete cascade,
  customer_name text not null,
  customer_phone text not null,
  service text not null,
  quantity integer not null check (quantity > 0),
  specifications text not null,
  status text not null default 'order_received',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Replace only this table's status constraint so the seven customer-facing stages are supported.
alter table public.customer_orders alter column status set default 'order_received';
alter table public.customer_orders drop constraint if exists customer_orders_status_check;
alter table public.customer_orders add constraint customer_orders_status_check
  check (status in ('order_received','design_in_progress','awaiting_approval','printing_in_progress','quality_check','completed','delivered_to_customer'));

alter table public.customer_orders enable row level security;

drop policy if exists "Customers view own orders" on public.customer_orders;
create policy "Customers view own orders" on public.customer_orders
for select to authenticated using (customer_id = auth.uid());

drop policy if exists "Customers create own orders" on public.customer_orders;
create policy "Customers create own orders" on public.customer_orders
for insert to authenticated with check (customer_id = auth.uid());

drop policy if exists "Staff view all customer orders" on public.customer_orders;
create policy "Staff view all customer orders" on public.customer_orders
for select to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin1')));

drop policy if exists "Staff update customer orders" on public.customer_orders;
create policy "Staff update customer orders" on public.customer_orders
for update to authenticated
using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin1')))
with check (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('admin1')));

grant select, insert on public.customer_orders to authenticated;
grant update (status) on public.customer_orders to authenticated;

-- Additive order-form fields. Existing customer order records are preserved.
alter table public.customer_orders add column if not exists item_type text;
alter table public.customer_orders add column if not exists sizes text;
alter table public.customer_orders add column if not exists colour text;
alter table public.customer_orders add column if not exists names_numbers text;
alter table public.customer_orders add column if not exists design_instructions text;
alter table public.customer_orders add column if not exists design_file_path text;
alter table public.customer_orders add column if not exists delivery_state text;
alter table public.customer_orders add column if not exists delivery_address text;
alter table public.customer_orders add column if not exists delivery_method text;
alter table public.customer_orders add column if not exists estimated_amount numeric(12,2) not null default 0;
alter table public.customer_orders add column if not exists deposit_paid numeric(12,2) not null default 0;

-- Private bucket for optional customer design/logo files (maximum 5 MB).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('order-designs', 'order-designs', false, 5242880,
  array['image/jpeg','image/png','image/webp','image/gif','application/pdf'])
on conflict (id) do update set public = false, file_size_limit = 5242880,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Customers upload own order designs" on storage.objects;
create policy "Customers upload own order designs" on storage.objects
for insert to authenticated with check (
  bucket_id = 'order-designs' and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "Customers view own order designs" on storage.objects;
create policy "Customers view own order designs" on storage.objects
for select to authenticated using (
  bucket_id = 'order-designs' and (
    (storage.foldername(name))[1] = auth.uid()::text or
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
  )
);


-- Ask Supabase/PostgREST to refresh its API schema cache after setup.
notify pgrst, 'reload schema';
