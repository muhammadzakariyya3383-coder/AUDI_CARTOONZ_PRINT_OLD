import { useCallback, useEffect, useState } from "react";
import { supabase } from "../lib/supabase";

type Order = {
  id: string; order_number: string; service: string; item_type?: string; quantity: number;
  specifications: string; sizes?: string; colour?: string; names_numbers?: string;
  design_instructions?: string; design_file_path?: string; delivery_state?: string;
  delivery_address?: string; delivery_method?: string; estimated_amount?: number;
  deposit_paid?: number; customer_name: string; customer_phone: string; status: string; created_at: string;
};
const ORDER_STAGES = [
  { key: "order_received", label: "Order Received" }, { key: "design_in_progress", label: "Design in Progress" },
  { key: "awaiting_approval", label: "Awaiting Approval" }, { key: "printing_in_progress", label: "Printing in Progress" },
  { key: "quality_check", label: "Quality Check" }, { key: "completed", label: "Completed" },
  { key: "delivered_to_customer", label: "Delivered to Customer" },
];
const itemTypes = ["Jersey", "T-shirt", "Cap", "Hoodie", "Uniform", "Other"];
const deliveryMethods = ["Pickup", "Dispatch rider", "Waybill", "Other"];
const money = (value?: number) => `₦${Number(value || 0).toLocaleString("en-NG")}`;
function stageLabel(status: string) { return ORDER_STAGES.find(s => s.key === status)?.label || status.replaceAll("_", " "); }

export default function Orders({ userId, isStaff, fullName }: { userId: string; isStaff: boolean; fullName: string }) {
  const [items, setItems] = useState<Order[]>([]);
  const [itemType, setItemType] = useState("Jersey");
  const [quantity, setQuantity] = useState("1");
  const [sizes, setSizes] = useState("");
  const [colour, setColour] = useState("");
  const [namesNumbers, setNamesNumbers] = useState("");
  const [designInstructions, setDesignInstructions] = useState("");
  const [designFile, setDesignFile] = useState<File | null>(null);
  const [deliveryState, setDeliveryState] = useState("");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [deliveryMethod, setDeliveryMethod] = useState("Pickup");
  const [estimatedAmount, setEstimatedAmount] = useState("");
  const [depositPaid, setDepositPaid] = useState("0");
  const [phone, setPhone] = useState("");
  const [customerName, setCustomerName] = useState(fullName);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!supabase) { setError("Supabase is not configured. Check the deployment environment secrets."); return; }
    setError("");
    let q = supabase.from("customer_orders").select("*").order("created_at", { ascending: false });
    if (!isStaff) q = q.eq("customer_id", userId);
    const { data, error: loadError } = await q;
    if (loadError) setError(`Could not load orders: ${loadError.message}`);
    else setItems((data || []) as Order[]);
  }, [userId, isStaff]);
  useEffect(() => { void load(); }, [load]);

  async function placeOrder(e: React.FormEvent) {
    e.preventDefault();
    if (!supabase) { setError("Supabase is not configured. Check the deployment environment variables."); return; }
    if (!customerName.trim() || !phone.trim() || !deliveryState.trim() || !deliveryAddress.trim() || !designInstructions.trim() || Number(quantity) < 1) {
      setError("Please complete your name, phone, quantity, design instructions and delivery address."); return;
    }
    if (designFile && designFile.size > 5 * 1024 * 1024) { setError("The design file must be 5 MB or smaller."); return; }
    if (designFile && !["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"].includes(designFile.type)) {
      setError("Please upload a JPG, PNG, WEBP, GIF or PDF sample file."); return;
    }
    setBusy(true); setError(""); setMessage("");
    let designFilePath: string | null = null;
    if (designFile) {
      const safeName = designFile.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      designFilePath = `${userId}/${Date.now()}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from("order-designs").upload(designFilePath, designFile, { upsert: false });
      if (uploadError) { setError(`Design upload failed: ${uploadError.message}. Ensure the order-designs storage bucket is configured.`); setBusy(false); return; }
    }
    const specifications = [
      `Sizes: ${sizes || "Not specified"}`, `Colour: ${colour || "Not specified"}`,
      `Names / numbers: ${namesNumbers || "Not specified"}`, `Design: ${designInstructions}`,
      `Delivery: ${deliveryMethod}, ${deliveryState}, ${deliveryAddress}`,
    ].join("\n");
    const { data, error: insertError } = await supabase.from("customer_orders").insert({
      customer_id: userId, service: itemType, item_type: itemType, quantity: Number(quantity), specifications,
      sizes: sizes.trim(), colour: colour.trim(), names_numbers: namesNumbers.trim(),
      design_instructions: designInstructions.trim(), design_file_path: designFilePath,
      delivery_state: deliveryState.trim(), delivery_address: deliveryAddress.trim(), delivery_method: deliveryMethod,
      estimated_amount: Number(estimatedAmount || 0), deposit_paid: Number(depositPaid || 0),
      customer_name: customerName.trim(), customer_phone: phone.trim(),
    }).select("order_number").single();
    if (insertError) {
      const missingTable = insertError.message.toLowerCase().includes("schema cache") || insertError.code === "PGRST205";
      setError(missingTable
        ? "Order was not saved because Supabase cannot find public.customer_orders. Run the supplied supabase/customer_orders_setup.sql in your existing Supabase SQL Editor, then refresh the app."
        : `Order was not saved: ${insertError.message}`);
    }
    else {
      setMessage(`Order submitted successfully. Your order number is ${data.order_number}.`);
      setQuantity("1"); setSizes(""); setColour(""); setNamesNumbers(""); setDesignInstructions("");
      setDesignFile(null); setDeliveryState(""); setDeliveryAddress(""); setEstimatedAmount(""); setDepositPaid("0");
      await load();
    }
    setBusy(false);
  }
  async function updateStatus(id: string, status: string) {
    if (!supabase) return;
    const { error: updateError } = await supabase.from("customer_orders").update({ status }).eq("id", id);
    if (updateError) setError(updateError.message); else await load();
  }

  return <div className="orders-page">
    {!isStaff && <section className="order-form-card">
      <p className="eyebrow">NEW PRINT REQUEST</p><h2>Place your order</h2>
      <p className="muted">Provide your garment, design, delivery and payment details. Our team will confirm the final price.</p>
      <form onSubmit={placeOrder} className="order-form">
        <label>Full name<input value={customerName} onChange={e => setCustomerName(e.target.value)} required /></label>
        <label>Contact phone<input type="tel" value={phone} onChange={e => setPhone(e.target.value)} required /></label>
        <label>Item type<select value={itemType} onChange={e => setItemType(e.target.value)}>{itemTypes.map(s => <option key={s}>{s}</option>)}</select></label>
        <label>Quantity<input type="number" min="1" value={quantity} onChange={e => setQuantity(e.target.value)} required /></label>
        <label>Sizes<input value={sizes} onChange={e => setSizes(e.target.value)} placeholder="e.g. S: 2, M: 5, L: 3" /></label>
        <label>Colour<input value={colour} onChange={e => setColour(e.target.value)} placeholder="e.g. Navy blue and white" /></label>
        <label className="full-field">Names / numbers<input value={namesNumbers} onChange={e => setNamesNumbers(e.target.value)} placeholder="List names, jersey numbers or write none" /></label>
        <label className="full-field">Design instructions<textarea rows={4} value={designInstructions} onChange={e => setDesignInstructions(e.target.value)} required placeholder="Describe your design, logo placement, style and any special requirements." /></label>
        <label className="full-field">Upload sample design / logo (optional)<input type="file" accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,image/jpeg,image/png,image/webp,image/gif,application/pdf" onChange={e => setDesignFile(e.target.files?.[0] || null)} /><small className="muted">Select a JPG, PNG, WEBP, GIF image or PDF. Maximum size: 5 MB. The file is uploaded privately with your order.</small>{designFile && <small>{designFile.name}</small>}</label>
        <label>Delivery state<input value={deliveryState} onChange={e => setDeliveryState(e.target.value)} required placeholder="e.g. Plateau" /></label>
        <label>Delivery method<select value={deliveryMethod} onChange={e => setDeliveryMethod(e.target.value)}>{deliveryMethods.map(s => <option key={s}>{s}</option>)}</select></label>
        <label className="full-field">Delivery address<textarea rows={2} value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} required placeholder="Enter complete delivery address" /></label>
        <label>Estimated order amount (₦)<input type="number" min="0" step="0.01" value={estimatedAmount} onChange={e => setEstimatedAmount(e.target.value)} placeholder="0" /></label>
        <label>Deposit paid (₦)<input type="number" min="0" step="0.01" value={depositPaid} onChange={e => setDepositPaid(e.target.value)} /></label>
        <button className="primary-action" disabled={busy}>{busy ? "Saving order…" : "SAVE ORDER →"}</button>
      </form>
      {message && <div className="notice success">{message}</div>}{error && <div className="notice warning">{error}</div>}
    </section>}
    <section className="orders-list"><div className="section-heading"><div><h2>{isStaff ? "Customer orders" : "My orders"}</h2><p className="muted">{isStaff ? "Review requests and update progress." : "Your submitted requests, order details and status."}</p></div><button className="refresh-button" onClick={() => void load()}>Refresh</button></div>
      {items.length === 0 ? <div className="empty-state">{isStaff ? "Customer requests will appear here." : "Your orders will appear here after you submit them."}</div> : <div className="order-cards">{items.map(o => <article className="order-card" key={o.id}>
        <div className="order-card-top"><strong>{o.order_number}</strong><span className="order-status">{stageLabel(o.status)}</span></div>
        <h3>{o.item_type || o.service}</h3><p>{o.quantity} pieces · {o.customer_name}</p>
        <div className="order-detail-grid"><span><b>Sizes:</b> {o.sizes || "—"}</span><span><b>Colour:</b> {o.colour || "—"}</span><span><b>Names / numbers:</b> {o.names_numbers || "—"}</span><span><b>Delivery:</b> {[o.delivery_method, o.delivery_state].filter(Boolean).join(" · ") || "—"}</span><span><b>Estimated:</b> {money(o.estimated_amount)}</span><span><b>Deposit:</b> {money(o.deposit_paid)}</span></div>
        <p className="muted">{o.design_instructions || o.specifications}</p>
        {o.delivery_address && <p className="muted"><b>Address:</b> {o.delivery_address}</p>}
        {o.design_file_path && <p className="muted"><b>Design file:</b> {o.design_file_path}</p>}
        <div className="order-progress" aria-label={`Order progress: ${stageLabel(o.status)}`}>{ORDER_STAGES.map((stage, i) => <div key={stage.key} className={ORDER_STAGES.findIndex(x => x.key === o.status) >= i ? "progress-step done" : "progress-step"}><span>{i + 1}</span><small>{stage.label}</small></div>)}</div>
        {isStaff && <><p className="muted">Contact: {o.customer_phone}</p><label className="status-control">Update status<select value={o.status} onChange={e => void updateStatus(o.id, e.target.value)}>{ORDER_STAGES.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}</select></label></>}
        <small>{new Date(o.created_at).toLocaleString()}</small>
      </article>)}</div>}
    </section>
  </div>;
}
