# Customer order setup — required before testing

The error `Could not find the table 'public.customer_orders' in the schema cache` means the live Supabase project has not exposed this table to the API. The app ZIP cannot create a table in your Supabase project automatically.

1. Open the **same Supabase project** used by this app.
2. Open **SQL Editor** → **New query**.
3. Open `supabase/customer_orders_setup.sql` from this ZIP, copy the entire contents, paste it into the SQL Editor and click **Run**.
4. Confirm the query completes successfully. It creates/updates `public.customer_orders`, creates the private `order-designs` Storage bucket and adds customer upload/read and Admin1 access policies. It does not delete existing order records.
5. In Supabase → **Storage**, confirm the private bucket `order-designs` exists.
6. Refresh the deployed app, sign in as a customer, attach a small JPG/PNG/PDF sample and submit a test order.

If SQL reports an error, stop and share the exact error. Do not repeatedly run partial snippets or change existing profile/auth tables. If SQL succeeds but the app still reports the schema-cache error, wait briefly, refresh the app, and verify that the app's `VITE_SUPABASE_URL` points to this same Supabase project.

## File upload rules
- Accepted: JPG, PNG, WEBP, GIF, HEIC, HEIF and PDF
- Maximum size: 5 MB
- Files are stored in a private bucket under the signed-in customer's user ID.
- The order form requires a signed-in customer session.


## v20.5.1 upload fix
If the app was already deployed, deploy this release and run the updated `supabase/customer_orders_setup.sql` in the same Supabase project. The SQL updates the existing private bucket's allowed MIME types and recreates the customer upload/read policies without deleting order records. Confirm the `order-designs` bucket has a 5 MB file limit.
