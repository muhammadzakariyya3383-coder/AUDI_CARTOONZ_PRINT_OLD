import { useState } from "react";
import Orders from "./Orders";
import { APP_VERSION } from "../lib/version";

export default function CustomerDashboard({ userId, fullName }: { userId: string; fullName: string }) {
  const [page, setPage] = useState<"overview" | "orders">("overview");
  return <div className="customer-shell">
    <aside className="customer-sidebar">
      <div className="customer-brand"><span className="customer-logo">AC</span><span><strong>AUDI CARTOONZ PRINT</strong><small>CUSTOMER PORTAL</small></span></div>
      <p className="customer-nav-label">MY ACCOUNT</p>
      <button className={page==="overview"?"customer-nav active":"customer-nav"} onClick={()=>setPage("overview")}>Overview</button>
      <button className={page==="orders"?"customer-nav active":"customer-nav"} onClick={()=>setPage("orders")}>My orders</button>
      <div className="customer-side-bottom"><span className="customer-online"/> Customer account<button onClick={()=>import("../lib/supabase").then(m=>m.supabase?.auth.signOut())}>Sign out</button></div>
    </aside>
    <main className="customer-main">
      <header className="customer-topbar"><div><span className="customer-kicker">CUSTOMER PORTAL</span><h1>{page==="overview"?"Your dashboard":"My orders"}</h1></div><div className="customer-account">{fullName || "Customer"}</div></header>
      {page==="overview" ? <>
        <section className="customer-hero"><div><span className="customer-kicker">WELCOME TO AUDI CARTOONZ PRINT</span><h2>Hello{fullName ? `, ${fullName}` : ""}!</h2><p>Place a print order, follow its progress and stay updated at every stage.</p><button className="customer-cta" onClick={()=>setPage("orders")}>Place an order <span>→</span></button></div><div className="customer-hero-art">AC<span>PRINT</span></div></section>
        <section className="customer-info-grid"><article><span>YOUR ORDERS</span><strong>Track every job</strong><p>See the latest progress of each order in one place.</p><button onClick={()=>setPage("orders")}>View my orders →</button></article><article><span>NEED HELP?</span><strong>Contact our team</strong><p>Call 08163671639 or email Abubakaraudi888@gmail.com.</p><a href="tel:08163671639">Call us →</a></article></section>
        <section className="customer-how"><h2>How your order progresses</h2><p>We keep you informed from receiving your request through delivery.</p><div className="customer-stage-preview">{["Order Received","Design in Progress","Awaiting Approval","Printing in Progress","Quality Check","Completed","Delivered to Customer"].map((s,i)=><div className="customer-stage" key={s}><span>{i+1}</span>{s}</div>)}</div></section>
      </> : <Orders userId={userId} isStaff={false} fullName={fullName}/>}
      <footer className="customer-footer">AUDI CARTOONZ PRINT · 08163671639 · Abubakaraudi888@gmail.com <span className="release-version">VERSION {APP_VERSION}</span></footer>
    </main>
  </div>;
}
