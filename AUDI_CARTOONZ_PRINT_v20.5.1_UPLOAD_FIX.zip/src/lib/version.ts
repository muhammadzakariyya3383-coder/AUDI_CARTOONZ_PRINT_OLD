/** Single source of truth for the application release displayed in the UI. */
export const APP_VERSION = "20.5.1";
