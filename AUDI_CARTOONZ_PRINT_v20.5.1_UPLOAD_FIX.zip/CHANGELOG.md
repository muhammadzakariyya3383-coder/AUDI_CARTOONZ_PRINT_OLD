# Changelog

## 20.5 — 2026-11-20
- Updated application release metadata to 20.5.
- Added a shared release constant and visible version labels in Admin1 and customer views.
- Updated the browser document title.
- Retained existing app modules, Supabase integration code, and database setup scripts without schema changes.
- No live Supabase connection or production deployment was performed as part of this package update.


## 20.5.1 — 2026-11-20
- Fixed sample upload MIME detection when browsers provide an empty or unexpected file type by detecting the file extension.
- Added HEIC and HEIF sample image support for common iPhone photo uploads.
- Updated the private order-designs bucket setup to allow HEIC/HEIF uploads.
- Added clearer error messages for missing Storage buckets and upload permission failures.
- Added a fallback upload ID generator for browsers without crypto.randomUUID().
