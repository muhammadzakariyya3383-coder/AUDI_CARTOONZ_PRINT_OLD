import { useEffect, useMemo, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured } from "./lib/supabase";
import { navigation, type NavKey, type Profile } from "./lib/types";
import SignIn from "./components/SignIn";
import Orders from "./components/Orders";
import CustomerDashboard from "./components/CustomerDashboard";

type OrderRow = { id:string; order_number:string; service:string; quantity:number; customer_name:string; customer_phone:string; status:string; created_at:string };
type CustomerRow = { id:string; full_name:string|null; phone:string|null; role:string };

function AdminModule({section,profile}:{section:NavKey;profile:Profile}) {
 const [orders,setOrders]=useState<OrderRow[]>([]),[customers,setCustomers]=useState<CustomerRow[]>([]),[loading,setLoading]=useState(true),[error,setError]=useState("");
 async function load(){
  if(!supabase){setError("Supabase is not configured. Add the project URL and anon key to the deployment environment.");setLoading(false);return;}
  setLoading(true);setError("");
  const orderResult=await supabase.from("customer_orders").select("id,order_number,service,quantity,customer_name,customer_phone,status,created_at").order("created_at",{ascending:false});
  if(orderResult.error)setError(`Orders data: ${orderResult.error.message}`);else setOrders((orderResult.data||[]) as OrderRow[]);
  if(section==="customers"){
   const customerResult=await supabase.from("profiles").select("id,full_name,phone,role").eq("role","customer").order("full_name");
   if(customerResult.error)setError(`Customer list: ${customerResult.error.message}`);else setCustomers((customerResult.data||[]) as CustomerRow[]);
  }
  setLoading(false);
 }
 useEffect(()=>{void load();},[section]);
 const active=orders.filter(o=>!['completed','delivered_to_customer'].includes(o.status));
 const totalQty=orders.reduce((n,o)=>n+Number(o.quantity||0),0);
 const title=navigation.find(n=>n.key===section)?.label||"Overview";
 const noTable=(name:string)=><div className="module-panel"><h2>{title}</h2><p>The original section is restored and accessible. The current Supabase project files do not define a verified <strong>{name}</strong> table, so this release does not invent or overwrite a database structure. Existing order and customer records remain unchanged.</p><p className="muted">Once the existing database structure is confirmed, this section can be connected safely.</p></div>;
 if(loading)return <section className="module-panel"><h2>{title}</h2><p className="muted">Loading live business records…</p></section>;
 if(section==="customers")return <section className="orders-list"><div className="section-heading"><div><h2>Customers</h2><p className="muted">Customer accounts from the existing profiles table.</p></div><button className="refresh-button" onClick={()=>void load()}>Refresh</button></div>{error&&<div className="notice warning">{error}</div>}{customers.length===0?<div className="empty-state">No customer profiles were returned.</div>:<div className="table-wrap"><table className="admin-table"><thead><tr><th>Name</th><th>Phone</th><th>Account ID</th></tr></thead><tbody>{customers.map(c=><tr key={c.id}><td>{c.full_name||"Unnamed customer"}</td><td>{c.phone||"—"}</td><td>{c.id}</td></tr>)}</tbody></table></div>}</section>;
 if(section==="production")return <section className="orders-list"><div className="section-heading"><div><h2>Production queue</h2><p className="muted">Live orders that still require production or handover.</p></div><button className="refresh-button" onClick={()=>void load()}>Refresh</button></div>{error&&<div className="notice warning">{error}</div>}{active.length===0?<div className="empty-state">There are no active production orders.</div>:<div className="order-cards">{active.map(o=><article className="order-card" key={o.id}><div className="order-card-top"><strong>{o.order_number}</strong><span className="order-status">{o.status.replaceAll("_"," ")}</span></div><h3>{o.service}</h3><p>{o.quantity} pieces · {o.customer_name}</p><p className="muted">{o.customer_phone}</p><small>{new Date(o.created_at).toLocaleString()}</small></article>)}</div>}</section>;
 if(section==="activity")return <section className="orders-list"><div className="section-heading"><div><h2>Recent order activity</h2><p className="muted">Recent order records from the existing customer_orders table. This is not an audit log.</p></div><button className="refresh-button" onClick={()=>void load()}>Refresh</button></div>{error&&<div className="notice warning">{error}</div>}{orders.length===0?<div className="empty-state">No order activity is available yet.</div>:orders.slice(0,30).map(o=><article className="activity-row" key={o.id}><strong>{o.order_number}</strong><span>{o.customer_name} · {o.service}</span><span className="order-status">{o.status.replaceAll("_"," ")}</span><small>{new Date(o.created_at).toLocaleString()}</small></article>)}</section>;
 if(section==="payments")return noTable("payments / transactions");
 if(section==="expenses")return noTable("business expenses");
 if(section==="settings")return <section className="module-panel"><h2>Admin settings</h2><p>Signed in as <strong>{profile.full_name||"Admin1"}</strong>.</p><p>Administrator role: <strong>Admin1</strong></p><p className="muted">Account access is controlled by the existing Supabase profile and authentication settings. No live database settings are changed from this screen.</p><button className="refresh-button" onClick={()=>void load()}>Refresh account data</button></section>;
 return <section className="module-panel"><h2>{title}</h2><p>Choose a section from the dashboard navigation.</p><div className="stats-grid"><div className="stat-card"><span>Total orders</span><strong>{orders.length}</strong></div><div className="stat-card"><span>Active orders</span><strong>{active.length}</strong></div><div className="stat-card"><span>Pieces ordered</span><strong>{totalQty}</strong></div><div className="stat-card"><span>Customers</span><strong>—</strong></div></div>{error&&<div className="notice warning">{error}</div>}</section>;
}

export default function App(){
 const [session,setSession]=useState<Session|null>(null),[profile,setProfile]=useState<Profile|null>(null),[section,setSection]=useState<NavKey>("overview"),[loading,setLoading]=useState(true),[error,setError]=useState("");
 useEffect(()=>{if(!supabase){setLoading(false);return;}supabase.auth.getSession().then(({data})=>setSession(data.session));const {data:listener}=supabase.auth.onAuthStateChange((_e,next)=>setSession(next));return()=>listener.subscription.unsubscribe();},[]);
 useEffect(()=>{let active=true;async function load(){if(!supabase||!session?.user){setProfile(null);setLoading(false);return;}setLoading(true);const {data,error}=await supabase.from("profiles").select("id,full_name,role,phone").eq("id",session.user.id).maybeSingle();if(!active)return;if(error)setError(error.message);setProfile(data as Profile|null);setLoading(false);}void load();return()=>{active=false;};},[session]);
 if(!isSupabaseConfigured||!session)return <SignIn/>;if(loading)return <div className="center-screen">Loading your account…</div>;if(!profile)return <div className="center-screen"><div className="notice warning">{error||"Your profile was not found. Ask the owner to check your profile."}</div><button onClick={()=>supabase?.auth.signOut()}>Sign out</button></div>;
 const staff=profile.role==="admin1";
 if(!staff)return <CustomerDashboard userId={session.user.id} fullName={profile.full_name||""}/>;
 const title=navigation.find(n=>n.key===section)?.label||"Overview";
 return <div className="app-shell"><aside className="sidebar"><div className="brand"><div className="brand-mark small">AC</div><div><strong>AUDI CARTOONZ PRINT</strong><span>PRINT MANAGEMENT</span></div></div><div className="side-label">WORKSPACE</div><nav>{navigation.map(n=><button key={n.key} className={section===n.key?"nav-item active":"nav-item"} onClick={()=>setSection(n.key)}>{n.label}</button>)}</nav><div className="sidebar-bottom"><span className="status-dot"/> Connected account<div className="muted tiny">ADMIN1</div><button className="signout" onClick={()=>supabase?.auth.signOut()}>Sign out</button></div></aside>
 <main className="main"><header className="topbar"><div><p className="eyebrow">BUSINESS WORKSPACE</p><h1>{title}</h1></div><div className="user-chip"><span className="avatar">{(profile.full_name||"A").slice(0,1).toUpperCase()}</span><span>{profile.full_name||session.user.email}</span></div></header>
 {section==="overview"?<><section className="welcome"><div><p className="eyebrow">WELCOME TO AUDI CARTOONZ PRINT</p><h2>Your printing business, organised.</h2><p>Manage customer print jobs from one workspace.</p></div><div className="welcome-icon">✦</div></section><div className="section-heading"><div><h2>Admin1 overview</h2><p className="muted">Open any workspace section below.</p></div></div><div className="stats-grid">{navigation.filter(n=>n.key!=="overview").map(n=><button className="stat-card" key={n.key} onClick={()=>setSection(n.key)}><span>{n.label}</span><strong>→</strong><small>Open {n.label.toLowerCase()}</small></button>)}</div><div className="contact-strip"><strong>Need help?</strong><span>Call 08163671639</span><span>Abubakaraudi888@gmail.com</span></div></>:section==="orders"?<Orders userId={session.user.id} isStaff fullName={profile.full_name||""}/>:<AdminModule section={section} profile={profile}/>}
 <footer>AUDI CARTOONZ PRINT · 08163671639 · Abubakaraudi888@gmail.com</footer></main></div>;
}
