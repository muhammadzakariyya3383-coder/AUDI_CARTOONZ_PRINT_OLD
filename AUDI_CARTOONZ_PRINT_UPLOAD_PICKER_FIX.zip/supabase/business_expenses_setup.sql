-- AUDI CARTOONZ PRINT: BUSINESS EXPENSES MODULE
-- Additive setup: creates a separate table and private receipt bucket.
-- Does not alter customer_orders, profiles, payments, or existing business records.
-- Run in the EXISTING Supabase project's SQL Editor as a project owner.

create table if not exists public.business_expenses (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(trim(title)) between 1 and 120),
  category text not null default 'Other',
  amount numeric(12,2) not null check (amount > 0),
  expense_date date not null default current_date,
  description text,
  payment_method text not null default 'Cash',
  receipt_path text,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists business_expenses_expense_date_idx
  on public.business_expenses (expense_date desc);
create index if not exists business_expenses_category_idx
  on public.business_expenses (category);
create index if not exists business_expenses_created_by_idx
  on public.business_expenses (created_by);

alter table public.business_expenses enable row level security;

-- Only the existing Admin1 profile can read expense records.
drop policy if exists "Admin1 can view business expenses" on public.business_expenses;
create policy "Admin1 can view business expenses"
on public.business_expenses for select to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin1'
  )
);

-- Only Admin1 can create records, and created_by must be the signed-in user.
drop policy if exists "Admin1 can create business expenses" on public.business_expenses;
create policy "Admin1 can create business expenses"
on public.business_expenses for insert to authenticated
with check (
  created_by = auth.uid()
  and exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin1'
  )
);

drop policy if exists "Admin1 can update business expenses" on public.business_expenses;
create policy "Admin1 can update business expenses"
on public.business_expenses for update to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin1'
  )
)
with check (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin1'
  )
);

drop policy if exists "Admin1 can delete business expenses" on public.business_expenses;
create policy "Admin1 can delete business expenses"
on public.business_expenses for delete to authenticated
using (
  exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin1'
  )
);

grant select, insert, update, delete on public.business_expenses to authenticated;

-- Private receipt storage: 5 MB maximum; supported types are images and PDF.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'expense-receipts',
  'expense-receipts',
  false,
  5242880,
  array['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
)
on conflict (id) do update set
  public = false,
  file_size_limit = 5242880,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Admin1 can upload expense receipts" on storage.objects;
create policy "Admin1 can upload expense receipts"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'expense-receipts'
  and (storage.foldername(name))[1] = auth.uid()::text
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
);

drop policy if exists "Admin1 can view expense receipts" on storage.objects;
create policy "Admin1 can view expense receipts"
on storage.objects for select to authenticated
using (
  bucket_id = 'expense-receipts'
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
);

drop policy if exists "Admin1 can delete expense receipts" on storage.objects;
create policy "Admin1 can delete expense receipts"
on storage.objects for delete to authenticated
using (
  bucket_id = 'expense-receipts'
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
);

comment on table public.business_expenses is
  'AUDI CARTOONZ PRINT business expense records; managed by Admin1 only.';

-- Refresh the PostgREST schema cache so the app can see the new table.
notify pgrst, 'reload schema';
