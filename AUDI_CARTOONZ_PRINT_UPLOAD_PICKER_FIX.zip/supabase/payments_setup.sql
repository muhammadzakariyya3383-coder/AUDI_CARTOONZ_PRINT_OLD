-- AUDI CARTOONZ PRINT Payments — additive setup for the existing Supabase project.
-- Does not delete, replace, or rewrite existing customers or orders.
-- Run only after confirming public.customer_orders and public.profiles exist.

alter table public.customer_orders
  add column if not exists final_amount numeric(12,2) not null default 0;

create table if not exists public.order_payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.customer_orders(id) on delete restrict,
  customer_id uuid not null references auth.users(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  currency text not null default 'NGN' check (currency = 'NGN'),
  transaction_type text not null default 'payment' check (transaction_type in ('payment','refund')),
  method text not null check (method in ('Cash','Bank Transfer','POS','Other','Paystack')),
  status text not null default 'confirmed' check (status in ('pending','confirmed','failed','refunded')),
  reference text unique,
  gateway_transaction_id text,
  note text,
  created_by uuid references auth.users(id) on delete set null,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists order_payments_order_id_idx on public.order_payments(order_id, created_at desc);
create index if not exists order_payments_customer_id_idx on public.order_payments(customer_id, created_at desc);
create index if not exists order_payments_status_idx on public.order_payments(status);

alter table public.order_payments enable row level security;

-- Customers can read only transactions belonging to their own orders.
drop policy if exists "Customers view own order payments" on public.order_payments;
create policy "Customers view own order payments" on public.order_payments
for select to authenticated using (customer_id = auth.uid());

-- Admin1 can read all transactions.
drop policy if exists "Admin1 view all order payments" on public.order_payments;
create policy "Admin1 view all order payments" on public.order_payments
for select to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
);

-- Admin1 alone can record manual payments/refunds.
drop policy if exists "Admin1 create order payments" on public.order_payments;
create policy "Admin1 create order payments" on public.order_payments
for insert to authenticated with check (
  created_by = auth.uid()
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
  and method <> 'Paystack'
);

drop policy if exists "Admin1 update order payments" on public.order_payments;
create policy "Admin1 update order payments" on public.order_payments
for update to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
) with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
);

grant select on public.order_payments to authenticated;
grant insert, update on public.order_payments to authenticated;
grant update (final_amount) on public.customer_orders to authenticated;

-- A dedicated Admin1 policy allows setting the approved final order price.
drop policy if exists "Admin1 can set final order amount" on public.customer_orders;
create policy "Admin1 can set final order amount" on public.customer_orders
for update to authenticated using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
) with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin1')
);

comment on table public.order_payments is
  'AUDI CARTOONZ PRINT manual and Paystack payment transactions. Paystack writes are performed only by trusted Edge Functions using the service role key.';
comment on column public.customer_orders.final_amount is
  'Admin1-approved final order price in NGN. Customer-entered estimated_amount is not used as the online checkout amount.';

notify pgrst, 'reload schema';
