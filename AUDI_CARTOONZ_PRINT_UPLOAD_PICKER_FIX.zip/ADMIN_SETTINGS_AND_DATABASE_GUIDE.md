# Admin settings and customer_orders repair

## Expanded Admin1 settings
The Settings screen now supports editing the signed-in administrator's profile name and phone number, requesting a login-email change, and changing the password. Email changes may require confirmation from the new inbox. These actions use Supabase Auth / the existing `profiles` table; they do not change the administrator role.

## Why Orders, Production and Activity show the same error
All three screens read `public.customer_orders`. The message `Could not find the table ... in the schema cache` means the connected Supabase project's API cannot currently see that table. It is a database setup issue, not three separate dashboard issues.

1. Open the exact Supabase project whose URL is configured in the deployed app.
2. Open SQL Editor and run the complete `supabase/customer_orders_setup.sql` file from this ZIP.
3. Confirm the SQL Editor reports success. If it reports an error, do not ignore it; copy the full error message and resolve that first.
4. In Supabase, open Table Editor and confirm `public.customer_orders` exists.
5. In Project Settings > API, confirm the app is using this same project. Then reload the app. PostgREST schema cache reload is requested at the end of the SQL script.

The setup script is additive and uses `create table if not exists` / `add column if not exists`. Review it against any existing schema before running. Do not run it against a different Supabase project.

## Payments and Expenses
Those modules remain intentionally unconnected. The supplied project does not contain verified payments/transactions or expenses table definitions. Do not invent table names or run a guessed schema. Once the actual existing database schema is provided, connect these screens to it without replacing existing records.
