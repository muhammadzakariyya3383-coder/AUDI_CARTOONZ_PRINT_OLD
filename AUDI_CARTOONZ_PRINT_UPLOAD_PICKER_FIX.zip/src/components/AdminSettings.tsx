import { useState } from "react";
import { supabase } from "../lib/supabase";
import type { Profile } from "../lib/types";

export default function AdminSettings({ profile, email }: { profile: Profile; email: string }) {
  const [name, setName] = useState(profile.full_name || "");
  const [phone, setPhone] = useState(profile.phone || "");
  const [newEmail, setNewEmail] = useState(email || "");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setMessage(""); setError("");
    const { error: updateError } = await supabase.from("profiles").update({ full_name: name.trim(), phone: phone.trim() }).eq("id", profile.id);
    if (updateError) setError(`Profile was not updated: ${updateError.message}`);
    else setMessage("Administrator profile updated successfully.");
    setBusy(false);
  }

  async function saveEmail(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    setBusy(true); setMessage(""); setError("");
    const { error: updateError } = await supabase.auth.updateUser({ email: newEmail.trim() });
    if (updateError) setError(updateError.message);
    else setMessage("Email change requested. Check the new email inbox and follow Supabase's confirmation link if required.");
    setBusy(false);
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    if (password.length < 8) { setError("Use a password with at least 8 characters."); return; }
    if (password !== confirmPassword) { setError("The password confirmation does not match."); return; }
    setBusy(true); setMessage(""); setError("");
    const { error: updateError } = await supabase.auth.updateUser({ password });
    if (updateError) setError(updateError.message);
    else { setMessage("Password changed successfully."); setPassword(""); setConfirmPassword(""); }
    setBusy(false);
  }

  return <div className="settings-stack">
    <section className="module-panel settings-panel"><div className="settings-heading"><div><p className="eyebrow">ACCOUNT PROFILE</p><h2>Administrator details</h2><p className="muted">Update the name and phone number shown in your workspace.</p></div><span className="settings-role">ADMIN1</span></div>
      <form className="settings-form" onSubmit={saveProfile}><label>Full name<input value={name} onChange={e=>setName(e.target.value)} required /></label><label>Phone number<input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="Enter business contact number" /></label><label>Administrator role<input value="Admin1" disabled /></label><button className="primary-action" disabled={busy}>Save profile changes</button></form>
    </section>
    <section className="module-panel settings-panel"><p className="eyebrow">LOGIN SECURITY</p><h2>Change email address</h2><p className="muted">Supabase may require confirmation before the new email becomes active.</p><form className="settings-form" onSubmit={saveEmail}><label>Login email<input type="email" value={newEmail} onChange={e=>setNewEmail(e.target.value)} required /></label><button className="refresh-button" disabled={busy || newEmail.trim()===email}>Update email</button></form></section>
    <section className="module-panel settings-panel"><p className="eyebrow">PASSWORD & SECURITY</p><h2>Change password</h2><form className="settings-form" onSubmit={savePassword}><label>New password<input type="password" autoComplete="new-password" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} placeholder="At least 8 characters" required /></label><label>Confirm new password<input type="password" autoComplete="new-password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} required /></label><button className="primary-action" disabled={busy}>Save new password</button></form></section>
    <section className="module-panel settings-panel"><p className="eyebrow">WORKSPACE CONTROLS</p><h2>System information</h2><div className="settings-info"><div><span>Signed-in account</span><strong>{email || "Not available"}</strong></div><div><span>Account ID</span><strong>{profile.id}</strong></div><div><span>Access level</span><strong>Administrator (Admin1)</strong></div><div><span>Data connection</span><strong>Supabase authentication</strong></div></div><p className="muted settings-note">Payments, expenses, staff permissions and business-wide preferences will only be enabled after their database structure and access rules are confirmed. This screen does not create or overwrite those records.</p></section>
    {error && <div className="notice warning">{error}</div>}{message && <div className="notice success">{message}</div>}
  </div>;
}
