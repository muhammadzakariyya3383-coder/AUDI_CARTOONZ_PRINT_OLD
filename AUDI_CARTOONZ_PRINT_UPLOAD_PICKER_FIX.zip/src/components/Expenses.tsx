import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "../lib/supabase";

type Expense = {
  id: string; title: string; category: string; amount: number; expense_date: string;
  description: string | null; payment_method: string; receipt_path: string | null;
  created_at: string;
};
const categories = ["Materials", "Printing", "Equipment", "Maintenance", "Transport", "Utilities", "Rent", "Staff", "Marketing", "Packaging", "Other"];
const methods = ["Cash", "Bank transfer", "Card", "POS", "Other"];
const money = (value: number) => new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 2 }).format(Number(value || 0));
const today = () => new Date().toISOString().slice(0, 10);
const blank = { title: "", category: "Materials", amount: "", expense_date: today(), description: "", payment_method: "Cash" };

export default function Expenses({ userId }: { userId: string }) {
  const [rows, setRows] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [form, setForm] = useState(blank);
  const [editing, setEditing] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<File | null>(null);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [period, setPeriod] = useState("month");

  const load = useCallback(async () => {
    if (!supabase) { setError("Supabase is not configured."); setLoading(false); return; }
    setLoading(true); setError("");
    const { data, error: fetchError } = await supabase.from("business_expenses").select("id,title,category,amount,expense_date,description,payment_method,receipt_path,created_at").order("expense_date", { ascending: false }).order("created_at", { ascending: false });
    if (fetchError) setError(`Expenses could not be loaded: ${fetchError.message}. Confirm that the Expenses SQL setup has been run in this Supabase project.`);
    else setRows((data || []) as Expense[]);
    setLoading(false);
  }, []);
  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter(r => (categoryFilter === "All" || r.category === categoryFilter) && (!q || [r.title, r.category, r.description || "", r.payment_method].join(" ").toLowerCase().includes(q)));
  }, [rows, search, categoryFilter]);
  const monthStart = today().slice(0, 7);
  const yearStart = today().slice(0, 4);
  const periodRows = rows.filter(r => period === "month" ? r.expense_date.startsWith(monthStart) : r.expense_date.startsWith(yearStart));
  const periodTotal = periodRows.reduce((sum, r) => sum + Number(r.amount), 0);
  const allTotal = rows.reduce((sum, r) => sum + Number(r.amount), 0);

  function resetForm() { setForm(blank); setEditing(null); setReceipt(null); }
  async function save(e: React.FormEvent) {
    e.preventDefault(); if (!supabase) return;
    const amount = Number(form.amount);
    if (!form.title.trim() || !Number.isFinite(amount) || amount <= 0) { setError("Enter an expense name and an amount greater than zero."); return; }
    setBusy(true); setError(""); setMessage("");
    let receiptPath: string | null = rows.find(r => r.id === editing)?.receipt_path || null;
    if (receipt) {
      const safeName = receipt.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `${userId}/${crypto.randomUUID()}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from("expense-receipts").upload(path, receipt, { upsert: false, contentType: receipt.type || undefined });
      if (uploadError) { setError(`Receipt upload failed: ${uploadError.message}`); setBusy(false); return; }
      receiptPath = path;
    }
    const payload = { title: form.title.trim(), category: form.category, amount, expense_date: form.expense_date, description: form.description.trim() || null, payment_method: form.payment_method, receipt_path: receiptPath };
    const result = editing
      ? await supabase.from("business_expenses").update(payload).eq("id", editing).select("id").single()
      : await supabase.from("business_expenses").insert({ ...payload, created_by: userId }).select("id").single();
    if (result.error) setError(`Expense was not saved: ${result.error.message}`);
    else { setMessage(editing ? "Expense updated successfully." : "Expense saved successfully."); resetForm(); await load(); }
    setBusy(false);
  }
  async function remove(row: Expense) {
    if (!supabase || !window.confirm(`Delete expense “${row.title}”? This cannot be undone.`)) return;
    setBusy(true); setError(""); setMessage("");
    const { error: deleteError } = await supabase.from("business_expenses").delete().eq("id", row.id);
    if (deleteError) setError(`Expense was not deleted: ${deleteError.message}`);
    else { if (row.receipt_path) await supabase.storage.from("expense-receipts").remove([row.receipt_path]); setMessage("Expense deleted."); await load(); }
    setBusy(false);
  }
  async function openReceipt(path: string) {
    if (!supabase) return;
    const { data, error: signedError } = await supabase.storage.from("expense-receipts").createSignedUrl(path, 60);
    if (signedError) setError(`Receipt could not be opened: ${signedError.message}`);
    else if (data?.signedUrl) window.open(data.signedUrl, "_blank", "noopener,noreferrer");
  }
  function edit(row: Expense) {
    setEditing(row.id); setReceipt(null);
    setForm({ title: row.title, category: row.category, amount: String(row.amount), expense_date: row.expense_date, description: row.description || "", payment_method: row.payment_method });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function exportCsv() {
    const headers = ["Date", "Expense", "Category", "Amount (NGN)", "Payment method", "Description"];
    const values = filtered.map(r => [r.expense_date, r.title, r.category, r.amount, r.payment_method, r.description || ""]);
    const csv = [headers, ...values].map(line => line.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a"); a.href = url; a.download = `audi-cartoonz-expenses-${today()}.csv`; a.click(); URL.revokeObjectURL(url);
  }

  return <div className="expenses-stack">
    <section className="module-panel expense-summary">
      <div className="section-heading"><div><p className="eyebrow">BUSINESS COST CONTROL</p><h2>Expenses overview</h2><p className="muted">Track day-to-day spending for AUDI CARTOONZ PRINT.</p></div><button className="refresh-button" onClick={() => void load()} disabled={loading}>Refresh records</button></div>
      <div className="expense-stats"><article><span>Total recorded expenses</span><strong>{money(allTotal)}</strong><small>{rows.length} records</small></article><article><label htmlFor="expense-period">Period summary</label><select id="expense-period" value={period} onChange={e => setPeriod(e.target.value)}><option value="month">This month</option><option value="year">This year</option></select><strong>{money(periodTotal)}</strong><small>{periodRows.length} records in selected period</small></article></div>
    </section>

    <section className="module-panel expense-form-panel"><p className="eyebrow">{editing ? "UPDATE RECORD" : "NEW RECORD"}</p><h2>{editing ? "Edit expense" : "Add an expense"}</h2>
      <form className="expense-form" onSubmit={save}>
        <label>Expense name<input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. T-shirt materials" required maxLength={120}/></label>
        <label>Category<select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>{categories.map(c => <option key={c}>{c}</option>)}</select></label>
        <label>Amount (₦)<input type="number" min="0.01" step="0.01" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} placeholder="0.00" required/></label>
        <label>Expense date<input type="date" value={form.expense_date} onChange={e => setForm({ ...form, expense_date: e.target.value })} required/></label>
        <label>Payment method<select value={form.payment_method} onChange={e => setForm({ ...form, payment_method: e.target.value })}>{methods.map(m => <option key={m}>{m}</option>)}</select></label>
        <label>Receipt (optional)<input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={e => setReceipt(e.target.files?.[0] || null)}/><small>JPG, PNG, WEBP or PDF · maximum 5 MB</small></label>
        <label className="expense-description">Description / notes<textarea rows={3} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Add useful details (optional)" maxLength={1000}/></label>
        <div className="expense-form-actions"><button className="primary-action" disabled={busy}>{busy ? "Saving…" : editing ? "Save changes" : "Save expense"}</button>{editing && <button type="button" className="refresh-button" onClick={resetForm} disabled={busy}>Cancel edit</button>}</div>
      </form>
    </section>

    {error && <div className="notice warning">{error}</div>}{message && <div className="notice success">{message}</div>}
    <section className="orders-list expense-records"><div className="section-heading"><div><h2>Expense records</h2><p className="muted">Search, filter, edit or export your records.</p></div><button className="refresh-button" onClick={exportCsv} disabled={!filtered.length}>Export CSV</button></div>
      <div className="expense-filters"><input aria-label="Search expenses" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search expenses…"/><select aria-label="Filter by category" value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)}><option>All</option>{categories.map(c => <option key={c}>{c}</option>)}</select></div>
      {loading ? <div className="empty-state">Loading expenses…</div> : filtered.length === 0 ? <div className="empty-state">{rows.length ? "No expenses match your search." : "No expenses have been recorded yet. Add your first expense above."}</div> : <div className="table-wrap"><table className="admin-table expense-table"><thead><tr><th>Date</th><th>Expense</th><th>Category</th><th>Amount</th><th>Method</th><th>Receipt</th><th>Actions</th></tr></thead><tbody>{filtered.map(row => <tr key={row.id}><td>{row.expense_date}</td><td><strong>{row.title}</strong>{row.description && <small className="expense-row-note">{row.description}</small>}</td><td>{row.category}</td><td><strong>{money(Number(row.amount))}</strong></td><td>{row.payment_method}</td><td>{row.receipt_path ? <button className="text-action" onClick={() => void openReceipt(row.receipt_path!)}>View receipt</button> : "—"}</td><td><div className="expense-row-actions"><button className="text-action" onClick={() => edit(row)} disabled={busy}>Edit</button><button className="text-action danger-action" onClick={() => void remove(row)} disabled={busy}>Delete</button></div></td></tr>)}</tbody></table></div>}
    </section>
  </div>;
}
