# AUDI CARTOONZ PRINT — Expenses module setup

This release adds an Admin1-only Expenses module and a separate `public.business_expenses` table. It does not modify `customer_orders`, `profiles`, or create a payments table.

## Apply the database setup

1. Back up the current project as a precaution.
2. Open the existing Supabase project → SQL Editor → New query.
3. Open `supabase/business_expenses_setup.sql` and copy its entire contents (do not paste the filename).
4. Paste the SQL into the editor and click Run.
5. A successful run normally reports `Success. No rows returned` because the script contains DDL and a schema notification.
6. Sign out and sign back in to the deployed app, then open Admin1 → Expenses.

The SQL assumes the existing `public.profiles` table has `id` matching `auth.users.id` and a `role` column containing the exact value `admin1`. This is consistent with the role lookup already used by this app. If your actual schema differs, stop and inspect it rather than weakening the policies.

## Included features

- Create, edit and delete expense records.
- Expense name, category, amount in NGN, date, payment method and notes.
- Optional private receipt upload (JPG, PNG, WEBP or PDF; 5 MB maximum).
- Search and category filtering.
- This-month / this-year totals and all-time total.
- CSV export of the currently filtered records.
- Row Level Security restricts table and receipt access to Admin1.

## Deployment

Replace the existing repository files with this project release and deploy through the repository's existing GitHub Actions workflow. Preserve existing environment secrets (`VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`). Do not add a service-role key to the frontend.

Run `npm install` and `npm run build` before publishing. The archive has not been connected to or tested against your live Supabase project; after applying SQL, verify by creating a small test expense, editing it, exporting CSV, opening any receipt, and deleting the test record.
