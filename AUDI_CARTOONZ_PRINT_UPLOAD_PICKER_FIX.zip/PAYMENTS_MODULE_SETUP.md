# AUDI CARTOONZ PRINT — Payments module setup

This package adds a Payments workspace to the existing React/Supabase application. It keeps the existing Orders, Customers, Production, Activity, Expenses and Settings modules in place.

## Included

- Admin1 Payments dashboard with payment totals, order balances, transaction history and CSV export.
- Admin1 can set an approved final order amount and record cash, bank transfer, POS payments and refunds.
- Customer order cards show an online Paystack checkout button after Admin1 sets the final price.
- Paystack checkout is initialized and verified by Supabase Edge Functions. The browser never receives the Paystack secret key.
- Additive SQL creates `order_payments` and adds `customer_orders.final_amount`; it does not delete or rewrite existing orders or profiles.

## Important accounting rule

The customer-entered `estimated_amount` and `deposit_paid` fields are not treated as verified money. Admin1 must reconcile any deposit already received, record it as a confirmed manual payment, and set the approved `final_amount`. The remaining balance is calculated from confirmed transactions only.

## 1. Apply the database setup

1. Open your existing Supabase project SQL Editor.
2. Open `supabase/payments_setup.sql` from this package.
3. Review it, then run it once.
4. Confirm the SQL completes successfully. It is additive and leaves existing order/customer rows untouched.

## 2. Deploy the Paystack Edge Functions

The two function folders are included:

- `supabase/functions/paystack-initiate`
- `supabase/functions/paystack-verify`

Using the Supabase CLI from the project directory:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase secrets set PAYSTACK_SECRET_KEY=YOUR_PAYSTACK_SECRET_KEY SITE_URL=https://muhammadzakariyya3383-coder.github.io/AUDI_CARTOONZ_PRINT_OLD
supabase functions deploy paystack-initiate
supabase functions deploy paystack-verify
```

Use the **Paystack Secret Key**, not the public key. Keep it only in Supabase Edge Function secrets. Never paste it into React source code, GitHub Pages settings, or a public chat.

For testing, use Paystack test keys first. Switch to live keys only after successful test transactions and verification.

## 3. Deploy the website

The current GitHub Actions workflow builds the first ZIP archive in the repository root. Replace the existing root application ZIP with this updated package (keeping one root project ZIP only), commit the replacement to `main`, and wait for the GitHub Pages workflow to finish successfully.

## 4. First-use steps

1. Sign in as Admin1 and open Payments.
2. Select each order and save its approved final price.
3. Reconcile any deposits already received and record them as manual payments.
4. Customers can then open My Orders and choose **Pay Online with Paystack** for the outstanding balance.
5. Check that each online payment is marked confirmed only after the Paystack verification function validates its reference, NGN currency and exact amount.

## Security and limitations

- Only Admin1 can view all payment records, set final prices, and create manual payments/refunds.
- Customers can view only their own order payment records.
- Paystack payment records are written/verified by trusted Edge Functions using the Supabase service-role key.
- This source bundle has not been deployed to your production Supabase project. The SQL and Edge Functions must be installed there before checkout can work.
- A production build could not be run in this environment because npm dependencies could not be downloaded. Run `npm install` and `npm run build` in your normal GitHub Actions environment before publishing. Do not deploy if the Actions build fails.
